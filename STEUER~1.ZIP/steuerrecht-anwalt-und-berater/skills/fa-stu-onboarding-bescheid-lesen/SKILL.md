---
name: fa-stu-onboarding-bescheid-lesen
description: "Anleitung zum schnellen und vollstaendigen Erfassen jedes Steuerbescheids — von der Bekanntgabe bis zur Rechtsbehelfsbelehrung. Anwendungsfall Mandant bringt einen Bescheid Anwalt oder Steuerberater muss in zehn Minuten Einspruchsbedarf Fristen und materielle Angriffspunkte erkennen. Behandelt Bekanntgabe Drei-Tages-Fiktion Bestandskraft Vorlaeufigkeitsvermerk Vorbehalt der Nachpruefung Aenderungs- und Korrekturnormen §§ 129 164 165 172 173 175 AO und Rechtsbehelfsbelehrung. Output Checkliste Bescheid-Erstpruefung und Marker fuer Einspruchs- bzw. Aenderungsantrag. Abgrenzung zu anw-einspruch-finanzamt und fa-stu-finanzgerichtsklage-78-fgo."
---

# Steuerbescheid lesen — die ersten 10 Minuten

## Fachlicher Anker

- **Normen:** § 6a, § 164 AO, § 165 AO.
- **Entscheidungs-/Quellenanker:** Tragende Rechtsprechung nur mit Gericht, Datum, Aktenzeichen und frei prüfbarer Quelle einsetzen; keine Entscheidung aus Modellwissen erzwingen.
- **Quellenhygiene:** `references/quellenhygiene.md` und `references/zitierweise.md` beachten.

## Triage — kläre vor der Bearbeitung

1. Ist der Bescheid ein Erstbescheid Aenderungs- oder Berichtigungsbescheid?
2. Steht er unter Vorbehalt der Nachpruefung § 164 AO oder vorlaeufig § 165 AO?
3. Gibt es eine ordnungsgemaesse Rechtsbehelfsbelehrung (sonst Jahresfrist § 356 Abs. 2 AO)?
4. Wann ist Bekanntgabe bewirkt (Stempel, Drei-Tages-Fiktion § 122 Abs. 2 AO, ELSTER-Bereitstellung § 122a AO)?
5. Welche Besteuerungsgrundlagen wurden veraendert; gibt es Erlaeuterungstext am Bescheidende?
- **Was will der Mandant wirklich erreichen?** (Nicht: was steht im Standardweg, sondern: welches Ergebnis ist fuer den Mandanten persoenlich/wirtschaftlich das beste? Manchmal ist der schnellere Vergleich besser als der formal "richtige" Weg.)

## Rechtsgrundlagen

- **§ 122 AO** — Bekanntgabe von Verwaltungsakten.
- **§ 124 AO** — Wirksamkeit eines Verwaltungsakts.
- **§ 157 AO** — Form und Inhalt von Steuerbescheiden.
- **§ 164 AO** — Vorbehalt der Nachpruefung.
- **§ 165 AO** — Vorlaeufige Steuerfestsetzung.
- **§§ 129 172 173 174 175 AO** — Korrektur- und Aenderungsnormen.
- **§ 356 AO** — Rechtsbehelfsbelehrung; Folge fehlerhafter Belehrung.

## Aktuelle Rechtsprechung

- Rechtsprechung: keine Entscheidung aus Modellwissen zitieren; vor Ausgabe über offizielle oder frei zugängliche Quelle (bundesfinanzhof.de, bundesverfassungsgericht.de, dejure.org, openjur.de, gesetze-im-internet.de) mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage verifizieren.
- Keine Pauschalzitate aus BeckRS allein; jede Entscheidung muss auf eine primaere oder offene Sekundaerquelle ruckfuehrbar sein.

## Zentrale Normen

§ 122 AO · § 124 AO · § 157 AO · § 164 AO · § 165 AO · § 129 AO · § 172 AO · § 173 AO · § 174 AO · § 175 AO · § 356 AO

## Quellenregel

Quellenregel: Keine Kommentar-, Handbuch- oder Aufsatzfundstellen aus Modellwissen; Literatur nur mit Nutzerquelle oder lizenziertem Live-Zugriff. Verwaltungsanweisungen (BMF-Schreiben, OFD-Verfuegungen, AEAO, UStAE, EStR, KStR) ausschliesslich nach Verifikation aus bundesfinanzministerium.de oder offiziellen Amtsblaettern zitieren.

## Bescheid-Checkliste

| Pruefpunkt | Wo im Bescheid | Folge |
| --- | --- | --- |
| Adressat korrekt | Kopf | sonst Bekanntgabemangel |
| Steuerart und Zeitraum | Kopf | sonst Inhaltsmangel |
| Festgesetzter Betrag | Tenor | Basis fuer AdV-Antrag |
| Vorbehalt der Nachpruefung | Tenor / Erlaeuterungen | jederzeit Aenderung § 164 Abs. 2 AO |
| Vorlaeufigkeitsvermerk | Erlaeuterungen | Reichweite genau pruefen |
| Rechtsbehelfsbelehrung | Ende | fehlt oder fehlerhaft → Jahresfrist § 356 Abs. 2 AO |
| Erlaeuterungstext | letzte Seite | Indikator fuer Streitpunkt |


## Abgrenzung zu anderen Skills dieses Plugins

- Verfahrens-Sklls (`anw-einspruch-finanzamt`, `anw-aussetzung-vollziehung`, `anw-akteneinsicht-steuerakte`) decken den prozessualen Rahmen ab; dieser Skill liefert die **materielle** Begruendung.
- Bei steuerstrafrechtlichen Beruehrungspunkten parallel `fa-stu-steuerhinterziehung-370-ao` und `fa-stu-selbstanzeige-371-ao` aufrufen.
- Bei berufsrechtlichen Fragestellungen `fa-stu-stberg-vereinbare-taetigkeit` bzw. `fa-stu-rvg-steuerstreit` parallel ziehen.
