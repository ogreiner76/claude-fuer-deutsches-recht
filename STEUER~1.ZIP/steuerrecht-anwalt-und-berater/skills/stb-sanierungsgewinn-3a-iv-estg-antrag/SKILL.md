---
name: stb-sanierungsgewinn-3a-iv-estg-antrag
description: "Antrag nach § 3a Absatz 4 EStG: Form, Frist, Inhalt und Bindungswirkung. Nach Feststellung des Sanierungserfolgs ist der Antrag nicht mehr zurücknehmbar; strategische Konsequenzen sind vor Antragstellung abzuwägen."
---

# § 3a Abs. 4 EStG — Antrag und Bindungswirkung

## Fachlicher Anker

- **Normen:** § 3a Abs. 4 EStG, § 6a, § 3a Abs. 1 EStG.
- **Entscheidungs-/Quellenanker:** Tragende Rechtsprechung nur mit Gericht, Datum, Aktenzeichen und frei prüfbarer Quelle einsetzen; keine Entscheidung aus Modellwissen erzwingen.
- **Quellenhygiene:** `references/quellenhygiene.md` und `references/zitierweise.md` beachten.

## Worum geht es

§ 3a Abs. 4 EStG macht die Steuerbefreiung vom ausdrücklichen Antrag abhängig. Der Antrag wirkt bindend: Nach Feststellung des Sanierungserfolgs kann er nicht mehr zurückgenommen werden. Die Folge ist endgültig — alle steuerlichen Wahlrechte zu Verlustverbrauch und Aufwandsabzug sind dann gesetzt.

## Wann brauchen Sie diesen Skill / Kaltstart-Fragen

1. Soll der Antrag tatsächlich gestellt werden — oder reicht der Verlustvortrag (Sanity-Check)?
2. Wann ist der späteste Zeitpunkt für den Antrag?
3. Was sind die Folgen der Bindungswirkung für den Verlustvortrag?
4. Sind alle vier Voraussetzungen (§ 3a Abs. 1 EStG) dokumentiert?
5. Ist parallel § 7b GewStG zu beantragen?

## Rechtlicher Rahmen

- **§ 3a Abs. 4 EStG** — Antrag erforderlich; Bindungswirkung nach Sanierungserfolg.
- **§ 3a Abs. 1 EStG** — Materielle Voraussetzungen.
- **§ 3c Abs. 4 EStG** — Verlustverbrauch als zwingende Folge.
- **§ 7b GewStG** — paralleler Antrag.
- **§ 149 AO** — Steuererklärung.
- **§ 164 AO** — Festsetzung unter Vorbehalt; eventuelle Rücknahme der Steuerfestsetzung im Vorbehaltsverfahren.

## / Schritt für Schritt

| Schritt | Inhalt | Output |
|---|---|---|
| 1 | Sanity-Check: Verlustvortrag deckt Ertrag? | Wenn ja: kein Antrag |
| 2 | Vier Voraussetzungen § 3a Abs. 1 EStG dokumentiert? | Beweispaket |
| 3 | Sanierungsjahr identifizieren — Geschäftsjahr des Verzichts | Wirtschaftsjahr |
| 4 | Antrag formuliert — siehe Mustertext | Antragsentwurf |
| 5 | Antrag mit Steuererklärung für Sanierungsjahr einreichen (KSt-/ESt-Erklärung) | Eingegangen FA |
| 6 | Parallel § 7b GewStG-Antrag mit Gewerbesteuererklärung | Eingegangen FA |
| 7 | FA-Bearbeitung; ggf. Nachfragen, Steuerakten-Einsicht | Bescheid |
| 8 | Steuerbescheid Sanierungsjahr unter Vorbehalt § 164 AO? | Spätere Korrektur möglich |
| 9 | Bei Streit: Einspruch § 347 AO | Verfahren |
| 10 | Nach Sanierungserfolg: Bindungswirkung eingetreten | Keine Rücknahme |

## Trade-off-Matrix

| Antrag stellen? | Verlustvortrag? | Empfehlung |
|---|---|---|
| Ja | Niedrig vs. Sanierungsertrag | Ja zwingend |
| Ja | Hoch, deckt vollständig | Nein, entbehrlich (Sanity-Check) |
| Ja | Mittel, deckt teilweise | Ja für übersteigenden Teil |
| Ja | Bei Streit Bedürftigkeit/Eignung | Verbindliche Auskunft § 89 AO vorab |
| Ja | International | Vorher Betriebsstätten klären |
| Ja | Personengesellschaft | Antrag je Mitunternehmer prüfen |

## Praxistipps der alten Hasen

- **Bindungswirkung ist die Falle.** Stellen Sie nicht "vorsorglich" Antrag. Wenn sich später herausstellt, dass die Sanierung schwächer ist oder ein Verlustvortrag verfügbar wäre, sind Sie gebunden.
- **Steuerbescheid unter Vorbehalt § 164 AO sichern.** Im Sanierungsjahr kann der Sachverhalt sich noch entwickeln (z. B. weitere Verzichtsangebote). Vorbehalt lässt nachträgliche Anpassung zu — die Antragsbindungswirkung greift erst mit Erfolgsfeststellung.
- **§ 7b GewStG nicht vergessen.** Der Sanierungsantrag § 3a EStG / § 8 Abs. 1 KStG schließt die Gewerbesteuer-Befreiung NICHT automatisch ein. Eigener Antrag mit Gewerbesteuererklärung.
- **Form: keine bestimmte vorgeschrieben.** In der Praxis: ausdrücklicher Antragstext in der Steuererklärung oder beigefügtes Schreiben. Wichtig: Bezug auf § 3a Abs. 4 EStG und Sanierungsjahr.
- **Frist: praktisch mit Steuererklärung.** Eine spätere Antragstellung im Einspruchsverfahren ist umstritten; verlassen Sie sich nicht darauf.

## Mustertexte / Berechnungsbeispiele

### Muster Antrag § 3a Abs. 4 EStG (Anlage zur Steuererklärung)

```
[Briefkopf Steuerberater / Anwalt]
An das Finanzamt [Ort]
- Steuernummer [Nr.] / Sachgebiet [Nr.] -

Anlage zur [Körperschaft-/Einkommen-]Steuererklärung
[Wirtschaftsjahr] der [Firma]

Betreff: Antrag nach § 3a Abs. 4 EStG —
 Sanierungsertrag in Höhe von EUR [Betrag]

Sehr geehrte Damen und Herren,

namens und in Vollmacht unserer Mandantin beantragen wir die
Steuerbefreiung des im Wirtschaftsjahr [...] entstandenen
Sanierungsertrags in Höhe von EUR [Betrag] nach § 3a Abs. 1 EStG.

I. Sachverhalt
Die [Firma] befand sich im Wirtschaftsjahr [...] in einer
existenzbedrohenden Krise. Die in Anlage 1 beigefügte
Liquiditätsplanung und die in Anlage 2 beigefügte Krisen-
ursachenanalyse belegen die Sanierungsbedürftigkeit.

Durch im Anlagenkonvolut 3 beigefügte schriftliche Verzichts-
erklärungen der Gläubiger [...] verzichteten diese auf
Forderungen in Höhe von insgesamt EUR [Betrag]. Hieraus
ergibt sich ein außerordentlicher Ertrag (Sanierungsertrag)
in entsprechender Höhe.

II. Vier Voraussetzungen § 3a Abs. 1 EStG
1. Sanierungsbedürftigkeit: Anlagen 1 und 2.
2. Sanierungsfähigkeit: IDW S 6-Konzept vom [Datum] —
 Anlage 4.
3. Sanierungsabsicht der Gläubiger: Schriftliche
 Erklärungen — Anlagen 3.
4. Sanierungseignung: Maßnahmenkatalog und Quote —
 Anlage 5.

III. Berechnung Sanierungsertrag nach § 3a Abs. 3 EStG
Sanierungsertrag brutto EUR [A]
abzgl. zusammenhängende Aufwendungen EUR [B]
Sanierungsertrag netto EUR [A-B]
abzgl. Verlustvortrag § 3c Abs. 4 EStG EUR [C]
verbleibender steuerbefreiter Ertrag EUR [A-B-C]

IV. Anträge
1. Steuerbefreiung in Höhe von EUR [A-B-C] gem.
 § 3a Abs. 1 EStG.
2. Festsetzung unter Vorbehalt der Nachprüfung
 gem. § 164 AO bis Abschluss des Sanierungsverfahrens.

Mit freundlichen Grüßen
[Berater]
```

### Berechnungsschema mit Bindungswirkungs-Folge

```
Schritt 1: Antrag § 3a Abs. 4 EStG ► gestellt
Schritt 2: FA prüft vier Voraussetzungen
Schritt 3: FA stellt Sanierungserfolg fest
Schritt 4: Bindungswirkung greift ► Rücknahme ausgeschlossen
Schritt 5: Verlustvortrag wurde verbraucht ► dauerhaft weg
Schritt 6: Bei späterer Streit: nur noch Steuerbescheid-
 Korrektur, kein neuer Wahlrechtsweg
```

## Typische Fehler

- Antrag gestellt, obwohl Verlustvortrag voll deckt — Bindungswirkung greift dennoch.
- § 7b GewStG-Antrag vergessen; Gewerbesteuer voll steuerpflichtig.
- Antrag im Einspruchsverfahren nachgereicht; FA bestreitet Zulässigkeit.
- Vier Voraussetzungen nicht vollständig dokumentiert; FA lehnt ab.
- Sanierungsjahr falsch zugeordnet (Verzicht im Vorjahr, Antrag im Folgejahr).

## Querverweise

- `stb-sanierungsgewinn-3a-estg-grundtatbestand`
- `stb-sanierungsgewinn-verlustvortrag-sanity-check`
- `stb-sanierungsgewinn-3c-iv-estg-verlustreihenfolge`
- `stb-sanierungsgewinn-7b-gewstg-gewerbesteuer-parallel`
- `stb-sanierungsgewinn-bmf-2017-sanierungserlass-nachfolge`

## Quellen Stand 06/2026

- § 3a Abs. 1, 3, 4 EStG.
- § 8 Abs. 1 KStG (Verweis aus KSt).
- § 7b GewStG.
- § 3c Abs. 4 EStG.
- § 149 AO (Steuererklärung).
- § 164 AO (Vorbehalt der Nachprüfung).
- § 89 AO (verbindliche Auskunft).
- § 347 AO (Einspruch).
- BMF-Schreiben vom 27.04.2017 — vor Verwendung Stand prüfen.
- Rechtsprechung: keine Entscheidung aus Modellwissen zitieren; Quelle vor Ausgabe protokollieren.
