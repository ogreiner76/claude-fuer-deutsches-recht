---
name: stb-sanierungsgewinn-liquidation-nachrang-fg
description: "Solvente GmbH-Liquidation mit nachrangigem Gesellschafterdarlehen. Klaert mit der verifizierten FG-Koeln-Linie (Urteil v. 06.03.2012 — 13 K 3006/11, GmbHR 2012 Seite 977; vorgehend zu BFH I R 34/12) und mit BFH II R 19/01 die Frage, wann die Verbindlichkeit ausgebucht werden muss und ob ein etwaiger Sanierungsgewinn mangels Koerperschaftsteuersubjekt noch festsetzbar ist. Adressat ist der Steuerberater oder Rechtsanwalt, der eine GmbH ohne Insolvenz nur per Liquidation abwickeln will und ein hohes Gesellschafterdarlehen mit qualifiziertem Rangruecktritt im Bestand hat."
---

# Sanierungsgewinn — Liquidation, Nachrang und die FG-Koeln-Linie

## Fachlicher Anker

- **Normen:** § 6a, § 3a EStG, § 60 Abs. 1 Nr. 2 GmbHG.
- **Entscheidungs-/Quellenanker:** Tragende Rechtsprechung nur mit Gericht, Datum, Aktenzeichen und frei prüfbarer Quelle einsetzen; keine Entscheidung aus Modellwissen erzwingen.
- **Quellenhygiene:** `references/quellenhygiene.md` und `references/zitierweise.md` beachten.

## Worum geht es

Eine GmbH in solventer Liquidation mit einem hohen nachrangigen Gesellschafterdarlehen wirft eine Frage auf, die § 3a EStG **nicht** beantwortet: Ist beim Loeschungszeitpunkt ein steuerpflichtiger Gewinn aus dem Wegfall der Verbindlichkeit anzunehmen, oder nicht? Antwort: Wenn die FG-Koeln-Linie greift (siehe unten), entsteht der Gewinn rechentheoretisch zwar, ist aber **mangels Koerperschaftsteuersubjekt nicht mehr festsetzbar**. § 3a EStG ist im Liquidationsfall denklogisch ohnehin schwierig — die Sanierungseignung fehlt.

Dieser Skill behandelt die Konstellation systematisch.

## Wann brauchen Sie diesen Skill / Kaltstart-Fragen

1. Mandantin ist eine GmbH (oder UG, GmbH und Co. KG mit Komplementaer-GmbH) und steht vor der Liquidation — **nicht** Insolvenz.
2. Besteht ein Gesellschafterdarlehen mit qualifiziertem Rangruecktritt? Hoehe in EUR?
3. Hat die Gesellschafterin **ausdruecklich** erklaert, dass sie verzichtet, oder will sie das Darlehen bis zur Loeschung passiviert lassen?
4. Wie ist die Rangruecktrittsklausel formuliert (Tilgung aus „freiem Vermoegen" vs. „aus zukuenftigen Gewinnen oder Liquidationsueberschuss")?
5. Welche Aktiva, welche Drittglaeubiger, welches Sperrjahr-Datum?
6. Gibt es nennenswerte Verlustvortraege?

## Rechtlicher Rahmen

- **§ 60 Abs. 1 Nr. 2 GmbHG** — Aufloesungsbeschluss durch Gesellschafter.
- **§ 65 GmbHG** — Bekanntmachung und Glaeubigeraufruf.
- **§ 71 GmbHG** — Liquidations-Eroeffnungsbilanz, Schlussbilanz.
- **§ 73 GmbHG** — Sperrjahr und Verteilungsverbot.
- **§ 74 GmbHG** — Loeschung im Handelsregister und Vollbeendigung.
- **§ 1 KStG, § 11 KStG** — Liquidationsbesteuerung Koerperschaft.
- **§ 5 Abs. 2a EStG** — Passivierungsverbot bei „nur aus zukuenftigen Gewinnen oder einem etwaigen Liquidationsueberschuss" tilgbaren Verbindlichkeiten.
- **§ 3a EStG, § 3a Abs. 2 EStG** — Sanierungsbefreiung; Sanierungseignung bei Liquidation fraglich.
- **§ 17 EStG, § 17 Abs. 4 EStG** — Aufloesungsverlust und nachtraegliche Anschaffungskosten auf Gesellschafterebene.
- **§ 397 BGB** — Erlassvertrag.

### Verifizierte Rechtsprechung

- **FG Koeln, Urteil v. 06.03.2012 — 13 K 3006/11**, GmbHR 2012, 977 (vorgehend zu BFH I R 34/12 — Verpflichtungsklage auf verbindliche Auskunft, in Folge des FG-Urteils). Os. 7 woertlich:

> „Ist ausgeschlossen, dass ein GmbH-Gesellschafter die mit einer Rangruecktrittserklaerung verbundenen Darlehensforderungen gegenueber der GmbH erlassen wird, kann bei der Liquidation der GmbH der Verzicht nicht unterstellt und ein steuerpflichtiger Gewinn angenommen werden. Die Verbindlichkeit ist bis zum Abschluss der Liquidation, d.h. bis zur Loeschung im Handelsregister als Verbindlichkeit auszuweisen. Mit dem Erloeschen der GmbH erloeschen neben den Verbindlichkeiten auch eventuelle Verlustvortraege. Der dadurch rechtstheoretisch entstehende Gewinn ist mangels Koerperschaftsteuersubjekt nicht mehr steuerpflichtig."

- **BFH, Urteil v. 26.02.2003 — II R 19/01** — Verbindlichkeiten entfallen nicht allein durch Vermoegenslosigkeit oder Aufloesungsbeschluss.
- **BFH, Urteil v. 30.11.2011 — I R 100/10** — § 5 Abs. 2a EStG bei qualifiziertem Rangruecktritt (Abgrenzung).
- **OFD Frankfurt a. M.** — Verfuegung mit der Aussage, dass der blosse Liquidationsbeschluss kein konkludenter Forderungsverzicht ist (Aktualitaet vor Anwendung pruefen).

## / Schritt fuer Schritt

| Schritt | Inhalt | Output |
|---|---|---|
| 1 | Sachverhalt sauber erfassen: GmbH solvent? Drittglaeubiger gedeckt? Nachrangiges Darlehen? | Sachverhaltsblatt |
| 2 | Wortlaut der Rangruecktrittsklausel pruefen: „freies Vermoegen" oder „nur aus zukuenftigen Gewinnen"? | Klausel-Memo |
| 3 | § 5 Abs. 2a EStG-Falle pruefen: Bei „nur aus zukuenftigen Gewinnen"-Klauseln greift Passivierungsverbot — Ausbuchung waehrend der Liquidation noch bei fortbestehendem Steuersubjekt | Pruefvermerk |
| 4 | Wenn Klausel sauber (freies Vermoegen): FG-Koeln-Linie tragend | Memo Szenario A |
| 5 | Sanierungseignung § 3a EStG pruefen — fehlt regelmaessig bei Liquidation | Negativbefund |
| 6 | § 17 Abs. 4 EStG-Aufloesungsverlust auf Gesellschafterebene parallel pruefen | Spiegel-Memo |
| 7 | Verbindliche Auskunft § 89 Abs. 2 AO beim FA pruefen | Antragsentwurf |
| 8 | Liquidations-Eroeffnungsbilanz und Schlussbilanz vorbereiten | Bilanzentwurf |
| 9 | Loeschungsantrag beim Handelsregister nach Sperrjahr | Anmeldung HR |

## Trade-off-Matrix

| Strategie | Wirkung | Risiko |
|---|---|---|
| A — Darlehen bleibt passiviert bis Loeschung | Steuerausfall nach FG Koeln 13 K 3006/11 (mangels Subjekt) | § 5 Abs. 2a EStG-Falle bei unsauberer Klausel |
| B — Ausbuchung in Liquidations-Eroeffnungsbilanz | Sanierungsertrag entsteht bei fortbestehender GmbH | § 3a EStG kaum anwendbar — Sanierungseignung fehlt; voll steuerpflichtig |
| C — Ausdruecklicher Verzicht durch Gesellschafterin (§ 397 BGB) | Sofortige Ausbuchung, klare Verhaeltnisse | Sanierungsertrag voll steuerpflichtig; § 17 EStG-Spiegel wahrnehmen |
| D — Insolvenzverfahren statt Liquidation | § 3a EStG eher anwendbar | Insolvenzverfahrenkosten, Reputationsrisiko |

## Praxistipps der alten Hasen

- **Klauselwortlaut entscheidet ueber alles.** Eine reine „Tilgung-nur-aus-zukuenftigen-Gewinnen"-Klausel reisst die GmbH in § 5 Abs. 2a EStG hinein — Ausbuchung **vor** Loeschung mit voller Steuerlast bei der lebenden GmbH. Sauber formulieren: „Tilgung aus freiem Vermoegen" (BFH I R 100/10 zur Abgrenzung).
- **§ 3a EStG nicht reflexartig bemuehen.** Bei einer Liquidation fehlt die Sanierungseignung. Wer den Antrag § 3a Abs. 4 EStG dennoch stellt, riskiert ein Ablehnungsbescheid des FA und unnoetigen Streit. Lieber die FG-Koeln-Linie und § 17 Abs. 4 EStG-Spiegel argumentieren.
- **Aktualitaet der OFD-Frankfurt-Verfuegung pruefen.** Vor der Antragstellung beim FA klaeren, ob die Verfuegung noch gilt — manche Bundeslaender weichen ab.
- **Verbindliche Auskunft erspart Streit.** Bei Volumen ab ca. 1 Mio EUR Darlehensbestand lohnt der § 89 Abs. 2 AO-Antrag. Vorlaufzeit FA: drei bis sechs Monate; rechtzeitig vor Loeschungsantrag stellen.
- **§ 17 Abs. 4 EStG nicht vergessen.** Auf Ebene der Gesellschafterin ist der Aufloesungsverlust geltend zu machen, sofern Darlehensverlust als nachtraegliche Anschaffungskosten zu beruecksichtigen ist (zu den Grenzen siehe staend. Rspr. zu „eigenkapitalersetzenden Darlehen" / BMF-Schreiben).

## Quellenpflicht

Verbindliche Zitierweise: `references/zitierweise.md`. Die FG-Koeln-Fundstelle und die BFH-Linie sind in jedem Memo, Antrag und Mandantenbrief mit Gericht, Datum, Aktenzeichen, Fundstelle und ggf. Randnummer zu nennen. Os. 7 von 13 K 3006/11 ist woertlich zitierfaehig (s. oben).

## Ausgabeformat

- Memo im Gutachtenstil: Sachverhalt knapp; Frage; Kurzantwort; Subsumtion; Gesamtergebnis; Risiken; Quellenverzeichnis.
- Querverweise auf die Akten 05 (Rangruecktritt), 06 (§ 5 Abs. 2a EStG), 07 (BFH II R 19/01), 08 (Szenario A), 16 (FG Koeln) der Test-Akte Strassburger Handelshof — soweit das Mandat parallel laeuft.

## Beispiele

### Beispiel 1 — Klauselwortlaut sauber, Strategie A

GmbH solvent, Darlehen 2,4 Mio EUR mit Rangruecktritt „Tilgung aus freiem Vermoegen". Drittglaeubiger gedeckt. Strategie A: Passivierung bis Loeschung. Ergebnis: kein festsetzbarer Sanierungsgewinn nach FG Koeln 13 K 3006/11. § 17 Abs. 4 EStG-Aufloesungsverlust bei Gesellschafterin nach Massgabe der nachtraeglichen Anschaffungskosten-Linie.

### Beispiel 2 — Klauselwortlaut unsauber, § 5 Abs. 2a EStG greift

GmbH solvent, Darlehen 2,4 Mio EUR mit Rangruecktritt „Tilgung nur aus zukuenftigen Gewinnen". Folge: Passivierungsverbot greift in der Liquidations-Eroeffnungsbilanz. Sanierungsertrag entsteht bei fortbestehender GmbH. § 3a EStG nicht anwendbar (Sanierungseignung fehlt). Voll steuerpflichtig, KSt + GewSt. Mandantenwarnung erforderlich — Klausel haette frueh saniert werden muessen.

### Beispiel 3 — Ausdruecklicher Verzicht durch Gesellschafterin

GmbH solvent, Darlehen 2,4 Mio EUR, Gesellschafterin erklaert ausdruecklich Verzicht (§ 397 BGB). Folge: Sofortige Ausbuchung mit Sanierungsertrag in der Periode des Verzichts; § 3a EStG nicht anwendbar (Liquidation). Voll steuerpflichtig bei der GmbH; auf Gesellschafterebene § 17 Abs. 4 EStG-Spiegel.

## Typische Fehler

- Reflexartig § 3a EStG-Antrag gestellt — Sanierungseignung in Liquidation kaum darstellbar; Ablehnung erwartbar.
- Klauseltext nicht im Originalwortlaut geprueft; nur Etikett "qualifizierter Rangruecktritt" verwendet.
- BFH-Revisionsstand nicht aktualisiert; veraltete Argumentation.
- Liquidator versaeumt Steuererklaerung Abwicklungszeitraum (§ 11 KStG) — § 69 AO-Haftung.
- § 17 Abs. 4 EStG-Spiegel auf Gesellschafterebene nicht parallel geltend gemacht.

## Praxistipps der alten Hasen — Ergaenzung

- **Verbindliche Auskunft § 89 AO mit FG-Koeln-Bezug.** Wenn das FA der Linie folgt, wird der Antrag haeufig positiv beschieden; aktuelle OFD-Verfuegungen vorab pruefen.
- **Sperrjahr ausnutzen.** Das Sperrjahr nach § 73 GmbHG (mindestens 1 Jahr nach Bekanntmachung des Glaeubigeraufrufs) gibt Zeit, die Strategie zu finalisieren.
- **Loeschungsantrag erst nach Steuerakte.** Vor Loeschung sollten die FA-Verfahren abgeschlossen oder die Bescheide bestandskraeftig sein, um die Vollbeendigung nicht zu blockieren.

## Querverweise

- `stb-sanierungsgewinn-3a-estg-grundtatbestand`
- `stb-sanierungsgewinn-3a-estg-unternehmens-vs-person`
- `stb-sanierungsgewinn-rangruecktritt-und-5-abs-2a-estg`
- `stb-sanierungsgewinn-vermeidungsstrategien-praxis`
- `stb-sanierungsgewinn-forderungsverzicht-bilanzielle-darstellung`
- `insol-sanierungsgewinn-liquidation-statt-plan-folgen`
- `gk-sanierungsgewinn-forderungsverzicht-vs-mantelkauf-8c-kstg`

## Quellen Stand 06/2026

- **FG Koeln, Urteil v. 06.03.2012 — 13 K 3006/11, GmbHR 2012, 977** (vorgehend zu BFH I R 34/12). Os. 7 woertlich oben zitiert.
- BFH, Urteil v. 26.02.2003 — II R 19/01.
- BFH, Urteil v. 30.11.2011 — I R 100/10 (zu § 5 Abs. 2a EStG bei qualifiziertem Rangruecktritt).
- OFD Frankfurt a. M., Verfuegung (Aktualitaet vor Anwendung pruefen).
- §§ 60, 65, 71, 73, 74 GmbHG; § 1 KStG, § 11 KStG; § 5 Abs. 2a EStG; § 3a EStG; § 17 EStG; § 397 BGB.
- Verbindliche Zitierweise: `references/zitierweise.md`.
