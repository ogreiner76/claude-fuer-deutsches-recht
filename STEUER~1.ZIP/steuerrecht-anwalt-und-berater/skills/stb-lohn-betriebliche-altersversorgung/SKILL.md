---
name: stb-lohn-betriebliche-altersversorgung
description: "Betriebliche Altersversorgung bAV Grundlagen Durchführungswege. Anwendungsfall Beratung Mandant zu bAV Direktversicherung Pensionskasse Pensionsfonds Direktzusage Unterstuetzungskasse steuerliche und SV-rechtliche Behandlung. Methodik Vergleich Wege Foerderung. Output bAV-Beratungs-Notiz."
---

# Betriebliche Altersversorgung (bAV) — Grundlagen

## Fachlicher Anker

- **Normen:** § 6a, § 3 Nr. 63 EStG, § 100 EStG.
- **Entscheidungs-/Quellenanker:** Tragende Rechtsprechung nur mit Gericht, Datum, Aktenzeichen und frei prüfbarer Quelle einsetzen; keine Entscheidung aus Modellwissen erzwingen.
- **Quellenhygiene:** `references/quellenhygiene.md` und `references/zitierweise.md` beachten.

## Kernsachverhalt

Die betriebliche Altersversorgung (bAV) ist eine vom AG zugesagte Versorgungsleistung zugunsten des AN, die zusaetzlich zur gesetzlichen RV traegt. Funf Durchfuehrungswege (BetrAVG): Direktzusage, Unterstuetzungskasse, Direktversicherung, Pensionskasse, Pensionsfonds. Steuerliche Foerderung ueber § 3 Nr. 63 EStG (bis 8 Prozent BBG steuerfrei, bis 4 Prozent BBG SV-frei) sowie § 100 EStG (Foerderung Geringverdiener). Pflicht: AG-Zuschuss zur Entgeltumwandlung 15 Prozent nach BRSG.

## Kaltstart-Rueckfragen

1. Welcher Durchfuehrungsweg ist gewuenscht oder bereits eingerichtet?
2. Erfolgt die bAV durch Entgeltumwandlung (AN-finanziert) oder AG-finanziert?
3. Welche Beitragshoehe pro Monat?
4. Liegt eine Versorgungszusage vor (Vertragstext)?
5. Welche Steuerklasse hat der AN? (Geringverdiener-Foerderung § 100 EStG bei Niedriglohn)
6. Wann erfolgt der Renteneintritt des AN (Pruefung Vertragslaufzeit)?
7. Welche Mitarbeiterzahl im Betrieb (BAVAG-Beratungspflichten)?
8. Welche bAV-Tarifvertraege (z.B. Metall- und Elektroindustrie) sind anwendbar?

## Rechtlicher Rahmen

### Primaernormen

**BetrAVG** — Betriebsrentengesetz.

**§ 1 BetrAVG** — Zusagearten.

**§ 1a BetrAVG** — Anspruch Entgeltumwandlung; 15-Prozent-Zuschuss-Pflicht AG.

**§ 3 Nr. 63 EStG** — Steuerfreiheit Direktversicherung/Pensionskasse/Pensionsfonds bis 8 Prozent BBG.

**§ 100 EStG** — Foerderung Geringverdiener (Hochstgehalt ueber bAV-Beitrag).

**§ 19 EStG** — Versorgungsbezuege in Auszahlungsphase.

**§ 1 Abs. 1 Nr. 9 SvEV** — SV-Freiheit bAV-Beitraege bis 4 Prozent BBG-West RV (kumuliert).

**BRSG (Betriebsrentenstaerkungsgesetz)** — Reform 2018, weitere Anpassungen.

### Verwaltungsanweisungen

- BMF v. 06.12.2017 zur bAV-Reform.
- BMF v. 18.03.2022.
- DSV Rundschreiben.

## Workflow

### Phase 1 — Durchfuehrungsweg-Wahl

| Weg | Charakter | Steuer (Ansparphase) | SV (Ansparphase) | Auszahlung |
|---|---|---|---|---|
| Direktversicherung | Versicherungsvertrag AG zu Versicherer | Bis 8 Prozent BBG steuerfrei (§ 3 Nr. 63 EStG) | Bis 4 Prozent BBG SV-frei | Voll lohnsteuerpflichtig in Auszahlung |
| Pensionskasse | Sondervermoegen ueber Pensionskasse | Wie Direktversicherung | Wie Direktversicherung | Wie Direktversicherung |
| Pensionsfonds | Kapitalmarktorientiert | Wie Direktversicherung | Wie Direktversicherung | Wie Direktversicherung |
| Direktzusage | AG-eigene Versorgungszusage | Bei Auszahlung lohnsteuerpflichtig | SV-frei (bis BBG bei Auszahlung) | Voll lohnsteuerpflichtig |
| Unterstuetzungskasse | Eigene rechtsfaehige Kasse | Wie Direktzusage | Wie Direktzusage | Wie Direktzusage |

### Phase 2 — Steuerliche Foerderung § 3 Nr. 63 EStG

- Bis 8 Prozent der RV-BBG (West) steuerfrei.
- Davon bis 4 Prozent BBG zusaetzlich SV-frei.
- BBG-West RV 2025: 96.600 EUR/Jahr; 8 Prozent = 7.728 EUR steuerfrei, 4 Prozent = 3.864 EUR SV-frei (Sozialversicherungs-Rechengroessenverordnung 2026 zum Jahreswechsel pruefen).
- AN-Vorteil: niedrigeres Brutto in Ansparphase, hoehere Rente.

### Phase 3 — § 100 EStG Geringverdiener-Foerderung

- AG kann fuer AN mit Bruttolohn unter Schwellenwert (§ 100 Abs. 3 Nr. 3 EStG: 2.575 EUR/Monat seit dem Grundrentengesetz 2020; Schwellenwert wird nicht automatisch angepasst, bei Gesetzesaenderung pruefen) BAV-Foerderbetrag erhalten.
- Foerderbetrag: 30 Prozent des AG-Beitrags (max. 288 EUR/Jahr je AN — Stand 2025, § 100 Abs. 1 EStG; BMF-Schreiben zu § 100 EStG pruefen).
- AG verrechnet Foerderung mit abzufuehrender LSt in der LSt-Anmeldung.

### Phase 4 — § 1a BetrAVG 15-Prozent-Zuschuss

- Bei Entgeltumwandlung in Direktversicherung/Pensionskasse/Pensionsfonds: AG-Zuschuss-Pflicht 15 Prozent.
- Rechtsprechung: keine Entscheidung aus Modellwissen zitieren; vor Ausgabe über offizielle oder frei zugängliche Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage verifizieren.
- Geltung: fuer ab 2019 abgeschlossene Vereinbarungen (Bestand seit 2022).

### Phase 5 — Auszahlungsphase

- bAV-Renten lohnsteuerpflichtig in voller Hoehe (nachgelagerte Besteuerung).
- KV/PV-Pflicht in der Auszahlungsphase (Freibetrag fuer Pflichtversicherte Rentner nach § 226 Abs. 2 SGB V; aktueller Freibetrag ueber GKV-Spitzenverband pruefen).
- Sondersituation pauschal versteuerte Direktversicherung (§ 40b EStG a.F.): Auszahlung ggf. nicht voll steuerpflichtig (Altvertraege bis 2004).

### Phase 6 — Beratung Mandant

- Vergleich Durchfuehrungswege mit Mandant.
- Bei kleinen Mandanten oft Direktversicherung praktisch (kein eigener Pensionsverwaltungs-Aufwand).
- Bei Konzernen Pensionsfonds oder Direktzusage moeglich.
- Vertragstext mit Rechtsanwalt pruefen lassen.

## Output

- Beratungsnotiz zu bAV-Durchfuehrungsweg.
- Konfiguration in DATEV LODAS / Lohn und Gehalt.
- Versorgungszusage-Vertrag.

## Strategie und Praxis-Tipps

- Direktversicherung ist Standard fuer kleine Mandanten — wenig Aufwand, klare Foerderung.
- 4-Prozent-Grenze SV-Frei genau pruefen — daruber hinaus SV-pflichtig.
- AG-Zuschuss 15 Prozent ist Pflicht — wer das nicht zahlt, riskiert AN-Klagen.
- Bei Direktzusagen: bilanzielle Behandlung (Rueckstellung) zu beachten — § 6a EStG.
- StBVV: bAV-Beratung als Zusatzauftrag (Komplex).
- DATEV-Tipp: DATEV LODAS bAV-Konfiguration mit Versicherer-Schnittstelle.

## Querverweise

- `stb-lohn-direktversicherung-3-nr-63-estg` — Direktversicherung.
- `stb-lohn-vermoegenswirksame-leistungen` — VL.
- `stb-lohn-bav-doppelversorgung-foerderung` — Mehrere bAV-Wege.
- `stb-lohn-arbeitsvertrag-pruefung-lohn-relevant` — Vertragspruefung.

## Quellen und Updates

Stand: 05/2026.

- BetrAVG §§ 1, 1a.
- EStG §§ 3 Nr. 63, 19, 100; § 6a (Direktzusage-Rueckstellung).
- SGB IV; SvEV.
- BMF v. 06.12.2017, v. 18.03.2022.
- BRSG.
- BBG-West RV 2025: 96.600 EUR; § 100 EStG Schwellenwert 2.575 EUR/Monat, Foerderbetrag max. 288 EUR/Jahr (Stand 2025; Sozialversicherungs-Rechengroessenverordnung 2026 und BMF-Schreiben pruefen).

<!-- AUDIT 27.05.2026 | welle 6 | 5 Marker aufgeloest: 4 bestaetigt (Werte 2025 eingesetzt), 1 ersetzt (Rentner-Freibetrag Pruefhinweis ohne Marker) -->
