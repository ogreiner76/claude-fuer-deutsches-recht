---
name: stb-lohn-pruefungen-drv-bp-haftung-stb
description: "Prüfungen DRV-Prüfung Lohnsteuer-Aussenprüfung Steuerberater-Haftung. Anwendungsfall DRV-Prüfer kommt Prüfkriterien Nachforderung Haftungsrisiken Mandant. Methodik Vorbereitung Begleitung Reaktion. Output Prüfbericht Prüfverhandlung Massnahmen."
---

# DRV-Pruefung, Lohnsteuer-Aussenpruefung, StB-Haftung

## Fachlicher Anker

- **Normen:** § 6a, § 280 BGB, § 28p SGB IV.
- **Entscheidungs-/Quellenanker:** Tragende Rechtsprechung nur mit Gericht, Datum, Aktenzeichen und frei prüfbarer Quelle einsetzen; keine Entscheidung aus Modellwissen erzwingen.
- **Quellenhygiene:** `references/quellenhygiene.md` und `references/zitierweise.md` beachten.

## Kernsachverhalt

Die DRV-Sozialversicherungspruefung (alle 4 Jahre) und Lohnsteuer-Aussenpruefung des FA (anlassbezogen oder routinemaessig) sind die zentralen externen Pruefungen der Lohnbuchhaltung. Pruefthemen: SV-Status-Klassifikation, BBG-Einhaltung, Sachbezuege, Pauschalierungen, Aufzeichnungspflichten, Reisekosten. Der Steuerberater bereitet vor, begleitet die Pruefung und prueft Nachforderungen. Bei Pruefungsfehlern haftet der StB aus Mandantenvertrag (§ 280 BGB).

## Kaltstart-Rueckfragen

1. Welche Pruefung wird angekuendigt — DRV, Lohnsteuer-Aussenpruefung, BG-Pruefung, Zoll?
2. Welcher Pruefzeitraum (in der Regel 4 Jahre)?
3. Welche Pruefthemen sind erkennbar?
4. Liegen vorherige Pruefungs-Beanstandungen vor?
5. Welche kritischen Lohn-Themen im Mandantenbetrieb (Werkvertrag, Sachbezug, GGF-Status)?
6. Welche Unterlagen muessen vorgelegt werden?
7. Welcher Pruefer ist zustaendig?
8. Welche Mandantenkommunikation zur Pruefungsbegleitung?

## Rechtlicher Rahmen

### Primaernormen

**§ 28p SGB IV** — DRV-Pruefung (Pruefung der ordnungsgemaessen Beitragsleistung; in der Regel im 4-Jahres-Rhythmus).

**§ 42f EStG** — Lohnsteuer-Aussenpruefung (Pruefung beim AG durch das FA).

**§§ 193-203 AO** — Allgemeine Pruefungsbefugnis (subsidiaer; § 42f EStG ist lex specialis fuer LSt).

**§ 280 BGB** — Schadensersatz Pflichtverletzung (Anspruchsgrundlage Mandant gegen StB).

**§ 67 StBerG** — StB-Berufshaftpflicht (Pflicht-Versicherung).

**§ 33 StBVV** — Honorar Pruefungsbegleitung (Gegenstandswert Pruefungsergebnis).

### Verwaltungsanweisungen

- DRV-Rundschreiben zur Pruefung.
- BMF zu Lohnsteuer-Aussenpruefung.

## Workflow

### Phase 1 — Pruefungsankuendigung

- Schriftliche Ankuendigung mit Pruefzeitraum.
- Pruefungs-Inhalt grob benannt.
- Vorlage-Frist Unterlagen.
- Pruefdauer (in der Regel 3-5 Tage vor Ort).

### Phase 2 — Vorbereitung

| Unterlage | Pruefer-Anfrage |
|---|---|
| Lohnbuecher Sachkonten | Buchungs-Belege |
| AN-Stammdaten | Vertraege, ELStAM-Daten |
| Arbeitsvertraege | Vertragstexte |
| Sachbezugsdokumentation | Belege, Gutschein-Konfigurationen |
| Reisekosten-Belege | Belege, Erstattungsformulare |
| Dienstwagen | Listenpreis, Fahrtenbuch falls vorhanden |
| MiLoG-Aufzeichnungen | Stundenzettel |
| ELSTER-Quittungen | Lohnsteuer-Anmeldungen |
| DEUEV-Quittungen | SV-Meldungen |

### Phase 3 — Pruefungs-Themenschwerpunkte

| Thema | Risiko |
|---|---|
| Statusfeststellung GGF, Werkvertrag, Aushilfe | Nachforderung SV bis 4 Jahre |
| Minijob-Schwelle dauerhaft eingehalten? | Nachforderung |
| Sachbezuege ueber 50 EUR | Nachversteuerung LSt + SV |
| Dienstwagen 1-Prozent korrekt? | Lohnsteuer-Nachforderung |
| Pauschalierungen § 40 EStG | Nachversteuerung |
| Steuerfreie Auslagenerstattung Reisekosten | Pauschalbetraege Pruefung |
| § 3b EStG Sonn-/Nacht-Zuschlaege | Hoechstsatz und Grundlohngrenze |

### Phase 4 — Begleitung der Pruefung

- StB als Bevollmaechtigter vor Ort.
- Auf Fragen sachlich-fachlich antworten.
- Bei strittigen Punkten: nicht ueberhasten zustimmen; auf Pruefbericht warten.
- Dokumentation aller Pruefgespraeche.

### Phase 5 — Pruefbericht und Schlussbesprechung

- Pruefbericht mit Beanstandungen und Nachforderungen.
- Schlussbesprechung mit Pruefer und Mandant: strittige Punkte klaeren.
- Bei Streitpunkten: Einspruch (§ 347 AO) im Pruefungsbescheid.

### Phase 6 — Reaktion und Haftungs-Pruefung

- Bei Nachforderung: Mandant trgt SV oder LSt nach.
- Bei Fehler durch StB (z.B. falsche Klassifikation): Pruefung Berufshaftpflicht.
- Mandanten-Schadensersatzanspruch nach § 280 BGB pruefen.

## Output

- Pruefbericht in Mandantenakte.
- Nachforderungsbescheide.
- Massnahmen-Plan zur Vermeidung wiederholter Beanstandungen.

## Strategie und Praxis-Tipps

- DRV-Pruefung alle 4 Jahre Routine — Mandant rechtzeitig vorbereiten.
- Bei Lohnsteuer-Aussenpruefung haeufig Anlass aus E-Bilanz-Auffaelligkeiten oder Pruefung beim Unterauftragnehmer.
- StB-Haftungsrisiko hoch bei Sachbezugs-, GGF-Status-, Minijob-Fehlern — sorgfaeltige Dokumentation Standard.
- Pruefer-Argumente nicht vorschnell akzeptieren — bei zweifelhaften Rechtsfragen Anwalt einschalten.
- StBVV: Pruefungsbegleitung nach Gegenstandswert Pruefungsergebnis oder Zeithonorar.
- DATEV-Tipp: DATEV LODAS Pruefer-Sicht-Modus mit Pruefer-Datenexport.

## Querverweise

- `stb-drv-sozialversicherungspruefung` — DRV-Pruefung detailliert.
- `stb-lohn-gesellschafter-geschaeftsfuehrer-sv` — GGF-Status.
- `stb-lohn-streitfaelle-bag-bsg-haftungsrisiko` — BAG/BSG-Linien.
- `anw-aussenpruefung-strategien` — Aussenpruefung allgemein.

## Quellen und Updates

Stand: 05/2026.

- SGB IV § 28p.
- EStG § 42f.
- AO §§ 193-203.
- BGB § 280.
- StBerG § 67; StBVV § 33.
- DRV-Rundschreiben.
- BMF zu Lohnsteuer-Aussenpruefung.


## Qualitäts-Hardening

- Arbeite aktennah: Tatsachen, Belege, Fristen, Zuständigkeit und gewünschtes Arbeitsprodukt zuerst klären.
- Keine Rechtsprechung aus Modellwissen zitieren. Jede Entscheidung vor Ausgabe mit Gericht, Entscheidungsform, Datum, Aktenzeichen und frei oder amtlich prüfbarer Quelle absichern.
- Keine BeckRS-, juris-, Kommentar-, Handbuch- oder Aufsatz-Blindzitate. Literatur nur verwenden, wenn der Nutzer sie bereitstellt oder ein lizenzierter Live-Zugriff im konkreten Arbeitsschritt dokumentiert ist.
- Wenn eine Quelle, Randnummer, Behördenpraxis oder Frist nicht sicher geprüft ist, sichtbar als Prüfpunkt markieren und keine Scheinpräzision erzeugen.
- Ergebnisse so liefern, dass sie sofort weiterverwendbar sind: Kurzbild, Prüfpfad, Risikoampel, Lückenliste und konkrete nächste Schritte.
