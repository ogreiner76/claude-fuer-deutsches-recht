---
name: vergleichsverhandlung-strategie
description: "Arbeitsmodul zu vergleichsverhandlung strategie: prüft Normtext, Nutzerangaben, Fristen, Belege und verifizierte Rechtsprechung mit Gericht, Datum, Aktenzeichen und frei prüfbarer Quelle."
---

# Vergleichsverhandlung und Einigung im Steuerrecht (Beratung und Prozess)

## Fachlicher Anker

- **Normen:** § 6a, § 796a ZPO, § 794 Abs. 1 Nr. 1 ZPO.
- **Entscheidungs-/Quellenanker:** Tragende Rechtsprechung nur mit Gericht, Datum, Aktenzeichen und frei prüfbarer Quelle einsetzen; keine Entscheidung aus Modellwissen erzwingen.
- **Quellenhygiene:** `references/quellenhygiene.md` und `references/zitierweise.md` beachten.

## Fachkern: Vergleichsverhandlung und Einigung im Steuerrecht (Beratung und Prozess)

- **Spezialfrage (Vergleichsverhandlung und Einigung im Steuerrecht (Beratung und Prozess)):** Arbeitsmodul zu vergleichsverhandlung strategie: prüft Normtext, Nutzerangaben, Fristen, Belege und verifizierte Rechtsprechung mit Gericht, Datum, Aktenzeichen und frei prüfbarer Quelle.
- **Arbeitsweise:** Erst Sachverhalt, Norm, Frist, Zuständigkeit und Beweis klären; Rechtsprechung nur verifiziert als tragenden Beleg einsetzen.


## Aktuelle Rechtsprechung (Vergleich/Einigung)

- Rechtsprechung: keine Entscheidung aus Modellwissen zitieren; vor Ausgabe über offizielle oder frei zugängliche Quelle mit Gericht, Entscheidungsform, Datum, Aktenzeichen und tragender Aussage verifizieren.

## Quellenregel

Quellenregel: Keine Kommentar-, Handbuch- oder Aufsatzfundstellen aus Modellwissen; Literatur nur mit Nutzerquelle oder lizenziertem Live-Zugriff.
## Wann dieser Skill greift

- Sachverhalte aus dem Bereich Steuerrecht (Beratung und Prozess), in denen eine aussergerichtliche oder prozessbegleitende Einigung sinnvoll erscheint.
- Typische Konstellationen: Tatsaechliche Verstaendigung, Aussetzung der Vollziehung, Billigkeitsvergleich.
- Sowohl in der aussergerichtlichen Phase (vor Klage) als auch im laufenden Prozess (Gueteverhandlung, Hauptverhandlung).

## Vorbereitung der Verhandlung

### 1. BATNA und ZOPA bestimmen

- **BATNA** (Best Alternative to Negotiated Agreement): Was passiert, wenn wir uns nicht einigen? Kosten- und Zeit-Prognose Prozess, Erfolgsaussichten-Quote, Vollstreckungsrisiko.
- **WATNA** (Worst Alternative): schlimmster denkbarer Verlauf bei Klage/Klageabweisung.
- **Reservation Price** auf eigener Seite: untere Grenze der Akzeptanz.
- **ZOPA** (Zone of Possible Agreement): geschaetzte Schnittmenge zwischen eigener Reservation und der vermuteten Reservation der Gegenseite.

### 2. Interessen vs. Positionen

Klassisches Harvard-Konzept: nicht nur Positionen ("Ich will 100.000 Euro") sondern Interessen ("Ich brauche bis Jahresende Liquiditaet"). In Steuerrecht (Beratung und Prozess) typische Interessen-Cluster:

- Liquiditaet (Sofort-Zahlung vs. Ratenzahlung)
- Reputation (Gegnerin will keinen Prozess mit Pressewirkung)
- Zukunfts-Beziehung (Mieter und Vermieter, Arbeitgeberin und ehem. Arbeitnehmer, Geschaeftspartner)
- Steuerliche Optimierung (Vergleich vs. Klage: ertragsteuerliche Behandlung, USt-Frage)
- Vertraulichkeit (NDA im Vergleich)

### 3. Druckmittel und Hebel

- Frist (Klage-/Verjaehrungsfrist als Druckmittel der Gegenseite kennen und eigene Frist gezielt einsetzen).
- Eskalationsstufen ankuendigen ohne sie zu uebertreiben.
- Hinweis auf Beweismittel, ohne diese vollstaendig offen zu legen.
- Reputationsdruck (Presse, Branche, Berufsregeln) sehr massvoll, nur wenn ethisch vertretbar.

## Ablauf der Verhandlung

### Eroeffnung

- Anker setzen: erste Zahl/Position deutlich hoeher als Reservation, aber begruendbar.
- Begruendung mit konkreten Positionen aus AO, FGO, EStG, KStG, UStG, GewStG, ErbStG, BewG verknuepfen.

### Konzessionsphase

- In kleinen, begruendeten Schritten nachgeben.
- Jede Konzession an Gegenleistung knuepfen ("Wenn Sie X, dann koennen wir Y").
- Konzessionsmuster nicht linear (sonst extrapolierbar) sondern abnehmend.

### Endspiel

- Abschluss aktiv herbeifuehren ("Sind wir bei 47.500 dann durch?").
- Schweige-Pausen aushalten.
- Nachverhandlungs-Versuche der Gegenseite ("ein letztes Detail noch") freundlich, aber bestimmt zurueckweisen, wenn Substanz steht.

## Vergleichsentwurf - Pflichtbestandteile

### Bei aussergerichtlichem Vergleich

1. **Praeambel** mit kurzem Sachstand und Streitthema.
2. **Hauptregelung** (Zahlung, Leistung, Unterlassung, Rueckabwicklung).
3. **Faelligkeit** und Verzinsung.
4. **Sicherheiten** (Buergschaft, Hinterlegung, Sicherungsabtretung).
5. **Erfuellung gegen Erledigung:** keine Aufrechnung, Ratenausfall = Sofortfaelligkeit.
6. **Abgeltungs-/Vorbehaltsklausel:** "Mit diesem Vergleich sind alle wechselseitigen Anspruche aus dem zugrundeliegenden Sachverhalt abgegolten."
7. **Verschwiegenheit** (wenn von einer Partei gewuenscht).
8. **Steuerliche Behandlung** ggf. ausdruecklich, sonst Hinweis auf Steuerberatung.
9. **Salvatorische Klausel und Schriftform.**
10. **Vollstreckungstitel-Ersatz:** notarielle Beurkundung, Anwaltsvergleich nach § 796a ZPO, oder Schiedsvergleich.

### Bei Prozessvergleich

- Protokollvergleich nach § 794 Abs. 1 Nr. 1 ZPO (Vollstreckungstitel kraft Protokollierung).
- Widerrufsvorbehalt mit klarer Frist.
- Kostenregelung: ueblich Kostenaufhebung, ggf. Quote.
- Beteiligung der Streithelfer/Nebenintervenienten beachten.

## Risiken und Stolpersteine im Steuerrecht (Beratung und Prozess)

- Steuerliche Fehlbehandlung: Vergleichszahlung als Schadensersatz vs. Lohn vs. USt-pflichtige Leistung -> AO und ESt-/USt-Regeln pruefen.
- Vollmacht: Mandantin muss zustimmen, anwaltliche Vergleichsbefugnis muss in Vollmacht expliziert sein.
- Vollstreckbarkeit: aussergerichtlicher Vergleich ohne notarielle Form/Anwaltsvergleich ist kein Vollstreckungstitel.
- Verzicht zu weit gefasst: pauschale Abgeltungsklausel kann eigene Ansprueche unbeabsichtigt mit erfassen.
- Mandanten-Erwartung: Vergleich ist oft Kompromiss - Erwartungsmanagement vor Verhandlung.

## Pflicht-Output

1. **Verhandlungs-Memo** mit BATNA/WATNA, ZOPA-Schaetzung, Strategie.
2. **Vergleichsentwurf** (anwaltsvertraglich oder Protokollvergleich-Skript).
3. **Mandantenfreigabe** vor Unterzeichnung schriftlich.
4. **Steuer- und Vollstreckungs-Memo** zum Vergleich.
5. **Abschluss-Schreiben** an Gegenseite mit Kopien und Erfuellungsplan.


## Verhandlungs-Skripte

### Skript 1: Eroeffnung mit Ankerwert

> "Wir haben die Sache durchgerechnet. Auf Basis von AO und der aktuellen Rechtsprechung kommen wir auf eine Hauptforderung von X Euro plus Y Euro Nebenforderungen. Wir sind bereit, ueber eine Pauschalsumme zu sprechen, die die Sache abschliesst."

### Skript 2: Begruendete Konzession

> "Wir koennen Z Euro nachgeben, wenn Sie im Gegenzug die Klausel A streichen und einer Vertraulichkeitsvereinbarung zustimmen. Andernfalls bleiben wir bei der urspruenglichen Position."

### Skript 3: Abschluss-Frage

> "Wenn wir uns auf 47.500 Euro einigen und das Geld bis zum 30. dieses Monats fliesst, ist die Sache fuer Sie dann erledigt?"

### Skript 4: Walk-Away-Signal

> "Wir haben hier eine klare Linie. Wenn Sie nicht ueber die 35.000 Euro hinauskommen, werden wir Klage einreichen und sehen, wie das Gericht entscheidet."

## Stoerfeuer und Antwort-Bausteine

- **"Wir haben rechtsschutzversichert, uns ist der Prozess egal":** "Die Versicherung pruft Erfolgsaussichten. Wir koennen Ihnen gerne unser BVerfG-/BGH-Zitat zur Klage-Quote in diesen Faellen schicken."
- **"Wir warten erstmal das Urteil im Verfahren XY ab":** "Verjaehrung laeuft uns weg. Wir lassen den Schiedsspruch im Hintergrund mitlaufen."
- **"Ihre Mandantin hat sich rechtsmissbraeuchlich verhalten":** "Bitte praezisieren Sie - dann nehmen wir das ggf. in den Vergleich auf."

## Steuerliche Behandlung des Vergleichs

Im Bereich Steuerrecht (Beratung und Prozess) oft uebersehen:

- Vergleichszahlung als Schadensersatz (in der Regel keine USt, EStG je nach Art).
- Vergleich ueber Lohn-/Gehaltsanspruch -> Lohnsteuer- und SV-Abzug pruefen.
- Vergleichszahlung als Anwaltshonorar -> ggf. USt.
- Erbrechtliche Abfindung -> ggf. ErbStG.
- Hinweis im Vergleich: "Die steuerliche Behandlung ist nicht Gegenstand dieser Vereinbarung und obliegt der eigenen Steuerberatung der Parteien."

## Mediation als Alternative

- Wenn Beziehung erhalten bleiben soll (Familie, Geschaeftspartner, Mieter und Vermieter).
- Mediator unparteiisch, kein Entscheidungstraeger - braucht Vertraulichkeitsvereinbarung.
- Mediations-Vergleich kann durch Notar oder Anwaltsvergleich vollstreckbar gemacht werden.
- Foerderung MediationsG; in einigen Bundeslaendern Kostenuebernahme bei Familiensachen.

## Vollstreckbarkeit

- **Anwaltsvergleich nach § 796a ZPO:** anwaltlich beurkundeter Vergleich, mit Vollstreckungsklausel des Gerichts = Vollstreckungstitel.
- **Notarieller Vergleich:** als Schuldanerkenntnis mit Vollstreckungsunterwerfung.
- **Prozessvergleich:** § 794 Abs. 1 Nr. 1 ZPO, sofort vollstreckbar.
- **Schiedsvergleich:** Vollstreckbarerklaerung nach §§ 1054, 1060 ZPO.

## Vergleichs-Reichweite und Abgeltungsklausel

Klassische Stolperfalle in Steuerrecht (Beratung und Prozess):

- **Eng:** "Mit Zahlung sind alle Anspruche aus diesem Verfahren erledigt."
- **Mittel:** "Mit Zahlung sind alle Anspruche aus dem zugrundeliegenden Sachverhalt erledigt."
- **Weit:** "Mit Zahlung sind saemtliche bekannten und unbekannten Anspruche zwischen den Parteien erledigt." -> Vorsicht: Schadensersatz fuer noch nicht erkannte Schaeden ggf. weg.

## Cross-Refs

- `erstgespraech-mandatsannahme` (im selben Plugin) fuer die Erstaufnahme und Streitwertgrundlage.
- `schriftsatzkern-substantiierung` (im selben Plugin) fuer den Fall, dass Vergleichsverhandlungen scheitern und Klage erforderlich wird.
